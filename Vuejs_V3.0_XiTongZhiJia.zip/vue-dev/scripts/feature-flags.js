module.exports = {
  NEW_SLOT_SYNTAX: true,
  VBIND_PROP_SHORTHAND: false
}
