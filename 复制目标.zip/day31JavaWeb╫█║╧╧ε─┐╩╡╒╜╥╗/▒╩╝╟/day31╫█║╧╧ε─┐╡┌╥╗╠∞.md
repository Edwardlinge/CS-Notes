# day31综合项目第一天 #
**今日任务**

- 完成用户模块


## 项目准备工作

### 一,数据库设计

![img](img/tu_1.png)

+ 用户和订单:一对多
+ 商品和订单:多对多
+ 分类和商品:一对多

### 二,环境的搭建

#### 1.数据库和表

```sql
create database store_21;
use store_21;
CREATE TABLE `user` (
	`uid` varchar(32) NOT NULL,  
	 `username` varchar(20) DEFAULT NULL,
	 `password` varchar(20) DEFAULT NULL,
     `name` varchar(20) DEFAULT NULL,
	 `email` varchar(30) DEFAULT NULL,
	 `telephone` varchar(20) DEFAULT NULL,
	 `birthday` date DEFAULT NULL,
	 `sex` varchar(10) DEFAULT NULL,
	 `state` int(11) DEFAULT NULL,  
	 `code` varchar(64) DEFAULT NULL,
	 PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```

#### 2.新建项目

​	导入jar包,驱动 c3p0 dbutils beanutils jstl mail

​	导入配置文件和工具类

​	导入页面

#### 3.包结构

​	com.itheima.web.servlet

​	com.itheima.web.filter

​	com.itheima.service

​	com.itheima.service.impl

​	com.itheima.dao

​	com.itheima.dao.impl

​	com.itheima.bean

​	com.itheima.utils

​	com.itheima.constant



#### 4.编码过滤器

#### 5.BaseServlet的抽取【重点】  	

​	传统方式的开发一个请求对应一个Servlet:这样的话会导致一个模块的Servlet过多,导致整个项目的Servlet都会很多.能不能做一个处理?让一个模块都用一个Servlet处理请求.	

​	注册:http://localhost:8080/day31/userServlet?method=register

​	登录:http://localhost:8080/day31/userServlet?method=login

​	激活:http://localhost:8080/day31/userServlet?method=active

+ 以"模块为单位"创建Servlet的方式

  ```java
  class UserServlet extends HttpServlet{
    .. doGet(HttpServletRequest request, HttpServletResponse response){
      //1. 获得method请求参数
      String methodStr =  request.getParameter("method");
      //2. 判断对应是哪一个操作,调用相应的方法
      if("register".equals(methodStr)){
        // 注册, 调用regist()方法
        regist(request,response);
      }
     
      if("login".equals(methodStr)){
        // 登录, 调用login()方法
        login(request,response);
      }
      
      ....
      
    }
    //注册
    public  void regist(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    
     //登录
    public  void login(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    
  }

  ```



发现在上面的doGet方法里面,有大量的if语句,能不能不写if语句

​	注册:http://localhost:8080/day31/userServlet?method=regist

​	登录:http://localhost:8080/day31/userServlet?method=login

​	激活:http://localhost:8080/day31/userServlet?method=active

+ 优化后

  ```java

  :http://localhost:8080/day31/userServlet?method=regist
  class UserServlet extends HttpServlet{  //
    .. doGet(HttpServletRequest request, HttpServletResponse response){
      //1. 获得method请求参数(方法名)
      String methodStr =  request.getParameter("method");
   	//2. 获得字节码对象
      Class clazz =  this.getClass();
      //3. 根据方法名反射得到method对象
     Method method =   clazz.getMethod(methodStr,HttpServletRequest.class,HttpServletResponse.class);
      //4. 调用响应的方法
      method.invoke(this,request,response);
      
    }
    //注册
    public  void regist(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    
     //登录
    public  void login(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    
  }

  商品模块:
  添加商品:http://localhost:8080/day31/productServlet?method=add
  删除商品:http://localhost:8080/day31/productServlet?method=delete


  class ProductServlet extends HttpServlet{
    .. doGet(HttpServletRequest request, HttpServletResponse response){
      //1. 获得method请求参数(方法名)
      String methodStr =  request.getParameter("method");
   	//2. 获得字节码对象
      Class clazz =  this.getClass();
      //3. 根据方法名反射得到method对象
     Method method =   clazz.getMethod(methodStr,HttpServletRequest.class,HttpServletResponse.class);
      //4. 调用响应的方法
      method.invoke(this,request,response);
      
    }
    
     //添加商品
    public  void add(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    
       //删除商品
    public  void delete(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    ....
  }



  ```


  

+ 每一个模块对应一个Servlet,发现doGet()方法里面,代码都是重复的,所以抽取一个通用的BaseServlet(基类), 让各个模块Servlet继承BaseServlet.通用的BaseServlet   好处: 少写代码, 把公共的代码抽取 

  ```java
  class BaseServlet extends HttpServlet{ //什么叫Servlet-- 实现了Servlet接口. 不管是get/post去都会执行service()方法,所以在BaseServlet里面直接重写service()方法就可以了
    .. service(HttpServletRequest request, HttpServletResponse response){
      //1. 获得method请求参数(方法名)
      String methodStr =  request.getParameter("method");
   	//2. 获得字节码对象
      Class clazz =  this.getClass();
      //3. 根据方法名反射得到method对象
     Method method =   clazz.getMethod(methodStr,HttpServletRequest.class,HttpServletResponse.class);
      //4. 调用响应的方法
     String path =  method.invoke(this,request,response);
      if(path != null){
        request.getRequestDispacher(path).forward(request,response);
      }  
        
      
    }
    
   --------------------------------------------------------------------------------------------------
   用户模块: 
   	注册:http://localhost:8080/day31/userServlet?method=regist   this: 对象是谁,this就是谁
    
    //用户模块的Servlet
    class UserServlet extends BaseServlet{

       
    //注册
    public  String regist(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向  (转发/重定向)
     // request.getRequestDispacher("/login.jsp").forward(request,response);
    //  return "/login.jsp";
      response.sendRedirect();
      return null;
      
    }
    
     //登录
    public  String login(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
     //  request.getRequestDispacher("/index.jsp").forward(request,response);
       return "/index.jsp";
    }
      
   //激活
    public  String active(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
       //request.getRequestDispacher("/msg.jsp").forward(request,response);
      return "/msg.jsp";
    }
    
    
  }
  ----------------------------------------------------------------------------------------------------
  商品模块:
  	添加商品:http://localhost:8080/day31/productServlet?method=add
  	删除商品:http://localhost:8080/day31/productServlet?method=delete


  class ProductServlet extends BaseServlet{
     //添加商品
    public  void add(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    //删除商品
    public  void delete(HttpServletRequest request, HttpServletResponse response){
      //获得请求参数
      //调用业务
      //分发转向
    }
    
    ....
  }
    
  ```


​    

#### 



## 案例一：用户模块-用户注册

### 一，案例需求###
​	在register.jsp上填写用户的信息,点击保存,将用户信息保存到数据库中. 发送激活邮件给注册的用户.

​	![img](img/tu_2.png)

### 二，思路分析 ###

1. 修改 "注册" 的超链接

   ```
   <a href="${pageContext.request.contextPath }/userServlet?method=registUI">注册</a>
   ```

2. 创建UserServlet继承BaseServlet, 在UserServlet里面创建registUI()方法

3. 在registUI()方法里面, return 注册页面的路径

4. 在注册页面, 点击注册按钮, 把数据提交

   ```
   <form action="${pageContext.request.contextPath}/userServlet" method="post">
   	<input type="hidden" name="method" value="regist"/>
   	表单里面的标签都应该添加name属性
   </form>
   ```

5. 在userServlet里面创建regist()方法

6. 在regist()方法里面:

   ​	获得请求参数(BeanUtils),封装成一个User

   ​	调用业务,进行注册逻辑处理

   ​	分发转向(给用户提示)

7. 创建UserService

   ​	发送激活邮件

   ​	调用Dao

8. 创建UserDao

   ​	语句: insert into user values(?,....)

### 三,代码实现





## 案例二：用户模块-用户激活

### 一，案例需求

​		用户登录邮箱之后,点击邮箱中的连接,完成用户激活操作

​		![img](img/tu_3.png)

### 二，思路分析

1. 点击邮箱中的连接,向商城userServlet发送一个请求

   ```
   <a href='http://localhost:8080/store_21/userServlet?method=active&code="+user.getCode()+"'>点击激活</a>
   ```

2. 在UserServlet里面创建active()

3. 在active()方法里面

   ​	获得请求参数(code)

   ​	调用业务, 根据code获得User对象

   ​	判断User,给用户响应

4. 在UserService:

   ​	调用Dao, 根据code查询User

   ​	if(user != null){

   ​		//更新用户的状态(已激活)

   ​		//把code置为null

   ​	}

5. 在UserDao

   ​	selectByCode();

   ​	update();


### 三，代码实现



##  案例三: 用户模块-用户登录

### 一，案例需求

​	在登录页面上,输入用户名和密码,点击登录,完成登录操作

​	![img](img/tu_5.png)

### 二，思路分析

1. 在index.jsp点击 登录 连接,跳转到登录页面

2. 在 登录 页面. 点击 登录 按钮, 把数据提交到userServlet

   ```
   <form action="${pageContext.request.contextPath}/userServlet" method="post">
   	<input type="hidden" name="method" value="login"/>
   	用户名/密码
   </form>
   ```

3. 在UserServlet里面创建login()方法

4. 在login()方法里面

   ​	获得请求参数(用户名,密码)

   ​	调用业务, 根据用户名和密码来获得User对象

   ​	判断给用户响应

   ​	if(user != null){

   ​		//只能说明用户名和密码匹配,不能说明用户是否激活

   ​		if(用户已经激活){

   ​			//保存用户的登录状态(session)

   ​			// 重定向到网站首页

   ​		}else{

   ​			// 给用户提示去激活

   ​		}

   ​	}else{

   ​		//说明用户名和密码匹配, 给用户提示

   ​	}

### 三，代码实现



##  案例四: 用户模块-用户退出

### 一，案例需求

​	点击 index.jsp上 退出连接,退出当前的用户,跳转index.jsp

​	![img](img/tu_4.png)

### 二，思路分析

1. 点击 index.jsp上 退出 连接,向userservlet发送请求

   ```jsp
      .../userServlet?method=logout
   ```

2. 在userServlet里面创建logout() ,在logout()方法里面

   ​	获得session,移除session里面存的user

   ​	重定向网站首页

###  三，代码实现

## 扩展案例: 用户模块-记住用户名  

### 一，案例需求

​	登录成功之后,若勾选了记住用户名,下一次再登录的时候,会展示出来用户名

### 二，思路分析

1. 修改login方法的逻辑

   ​	登录成功之后,判断是否勾选了记住用户名.

   ​	若勾选了,将用户名保存到cookie中

   ​	在login.jsp页面.拿出用户名展示 用户名输入框

### 三，代码实现